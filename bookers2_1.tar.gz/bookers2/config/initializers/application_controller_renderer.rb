# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '5533dca6e05e004b42b675fd3366394cd80ae9cf72ba51810e8a7664eca4d517bc410f01893bd2a148f70c01f946b9d42bd689f53997b84f471c8a34fc63d3e9'