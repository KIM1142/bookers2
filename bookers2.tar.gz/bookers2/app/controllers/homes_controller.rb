class HomesController < ApplicationController
  def top
  end
  
  def home
  end
  
end
